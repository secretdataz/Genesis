#!/bin/sh
zenity --question --title="Genesis" --text="Are you sure you would like to restart your rAthena server?"
if [ $? = 0 ]; then
	killall login-server
	killall char-server
	killall map-server
	GENESIS_DIR=/usr/share/genesis
	xterm -title "Login Server" -bg black -fg white -hold -e $GENESIS_DIR/scripts/start_login_server.sh &
	sleep 1
	xterm -title "Char Server" -bg black -fg white -hold -e $GENESIS_DIR/scripts/start_char_server.sh &
	sleep 1
	xterm -title "Map Server" -bg black -fg white -hold -e $GENESIS_DIR/scripts/start_map_server.sh &
fi
