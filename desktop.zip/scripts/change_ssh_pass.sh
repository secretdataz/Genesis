#!/bin/sh
GENESIS_DIR=/usr/share/genesis
xterm -title "Change SSH Password" -bg black -fg white -hold -e sh $GENESIS_DIR/scripts/change_ssh_pass_script.sh &