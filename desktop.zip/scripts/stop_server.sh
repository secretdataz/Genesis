#!/bin/sh
zenity --question --title="Genesis" --text="Are you sure you would like to turn off your rAthena server?"
if [ $? = 0 ]; then
	killall login-server
	killall char-server
	killall map-server
	zenity --info --title="Genesis" --text="Your rAthena server has been stopped." 
else
	exit
fi
