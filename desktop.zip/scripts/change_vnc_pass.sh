#!/bin/sh
GENESIS_DIR=/usr/share/genesis
xterm -title "Change VNC Password" -bg black -fg white -hold -e sh $GENESIS_DIR/scripts/change_vnc_pass_script.sh &